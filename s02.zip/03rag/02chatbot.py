import os
import streamlit as st
from langchain.prompts import PromptTemplate
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from PIL import Image

os.environ["AZURE_OPENAI_API_TYPE"] = "azure"
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://aoi-datacitizen-practices.openai.azure.com"
os.environ["AZURE_OPENAI_API_KEY"] = "3lwQJSV6WUtsnkAqyv4350hfstiHYbaIYvHlKuhSlXMjN7sOScM3JQQJ99AKACYeBjFXJ3w3AAABACOGoi14"
os.environ["OPENAI_API_VERSION"] = "2024-06-01"

deployment_embedding = "text-embedding-3-small"
deployment_llm = "gpt-4o-mini"

st.set_page_config(page_title = "Chatbot - 2024", page_icon = "📉")

with st.sidebar:
    st.title("Chatbot - 2024")

    image = Image.open("ley-mineria.png")
    st.image(image, caption = "Ley de Minería")

    st.markdown(
        """        
        ### Propósito
        Este chatbot te permitirá realizar preguntas sobre la ley de minería.
        
        ### Fuente de datos que se ha considerado
        - Ley de Minería ed 2022 (https://www.gob.pe/institucion/minem/informes-publicaciones/3304361-tuo-de-ley-general-de-mineria-ed-2022)
    """
    )

msg_chatbot = """
        Soy un chatbot que te ayudará con preguntas sobre la ley de minería: 
        
        ### Preguntas que puedes realizar
        - Hazme un resumen con los principales puntos de la ley
        - ¿Cómo se aborda el bienestar y la seguridad de los trabajadores mineros?
        - ¿Cuáles son las actividades mineras y cómo se clasifican?
        - ¿Qué garantías y beneficios fiscales ofrece la ley para promover la inversión en minería?
"""

#Store the LLM Generated Reponese
if "messages" not in st.session_state.keys():
    st.session_state.messages = [{"role": "assistant", "content" : msg_chatbot}]

# Diplay the chat messages
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.write(message["content"])

# Clear the Chat Messages
def limpiar_historial():
    st.session_state.messages = [{"role" : "assistant", "content": msg_chatbot}]

def format_docs(docs):
    return "\n\n".join(doc.page_content for doc in docs)

# Create a Function to generate
def generate_response(prompt_input):

    template = """Responda a la pregunta basada en el siguiente contexto.
    Si no puedes responder a la pregunta, usa la siguiente respuesta "No lo sé disculpa, puedes buscar en internet 😉."

    Contexto: 
    {context}
    Pregunta: {question}
    Respuesta: 
    """

    prompt = PromptTemplate(
        input_variables = ["context", "question"],
        template = template
    )

    llm = AzureChatOpenAI(
        azure_deployment = deployment_llm,
        temperature = 0
    )

    embeddings = AzureOpenAIEmbeddings(azure_deployment = deployment_embedding)

    datafaiss = "dataleymineria"
    vectorstore = FAISS.load_local(datafaiss, embeddings, allow_dangerous_deserialization = True)

    #retriever = vectorstore.as_retriever(search_kwargs = {"k": 5})

    rag_chain = (
        {"context": vectorstore.as_retriever() | format_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )

    output = rag_chain.invoke(prompt_input)
    return output

st.sidebar.button('Limpiar historial de chat', on_click = limpiar_historial)

prompt = st.chat_input("Ingresa tu pregunta")
if prompt:
    st.session_state.messages.append({"role" : "user", "content" : prompt})
    with st.chat_message("user"):
        st.write(prompt)

# Generar una nueva respuesta si el último mensaje es de un user
if st.session_state.messages[-1]["role"] == "user":
    with st.chat_message("assistant"):
        with st.spinner("Esperando respuesta, dame unos segundos."):
            response = generate_response(prompt)
            placeholder = st.empty()
            placeholder.markdown(response)

    message = {"role" : "assistant", "content" : response}
    st.session_state.messages.append(message)